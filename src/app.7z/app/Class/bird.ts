export abstract class bird {
    name!: string;
    L!: number;
    constructor() {
    }
    abstract show():any;
    abstract f(): any;
}