export interface iShow {
    show(s:string):void;
}