export interface iTags {
    name : string; 
    population: number;
    area : number;
}