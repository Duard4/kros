export interface iDensity {
    density() : number;
}